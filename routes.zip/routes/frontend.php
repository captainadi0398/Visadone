<?php
Route::post('/user-register', 'App\Http\Controllers\FrontEndController@user_register');
